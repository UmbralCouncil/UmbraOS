#!/usr/bin/env bash
set -euo pipefail

VM_NAME="${VM_NAME:-nixos}"
CDROM_TARGET="${CDROM_TARGET:-sda}"
CDROM_BUS="${CDROM_BUS:-sata}"
LIBVIRT_URI="${LIBVIRT_URI:-qemu:///system}"

usage() {
  local status="${1:-2}"
  cat >&2 <<EOF
Usage: $0 'path/to/UmbraOS-*.iso'
       $0 -d

Options:
  -d            Eject media from all virtual CD-ROM drives and exit
  -h            Show this help

Environment overrides:
  VM_NAME       libvirt domain name       (default: nixos)
  CDROM_TARGET  guest CD-ROM target       (default: sda)
  CDROM_BUS     guest CD-ROM bus          (default: sata)
  LIBVIRT_URI   libvirt connection URI    (default: qemu:///system)
EOF
  exit "$status"
}

die() {
  printf 'Error: %s\n' "$*" >&2
  exit 1
}

DETACH_ONLY=false
while getopts ":dh" option; do
  case "$option" in
    d) DETACH_ONLY=true ;;
    h) usage 0 ;;
    :) usage ;;
    \?) usage ;;
  esac
done
shift "$((OPTIND - 1))"

if "$DETACH_ONLY"; then
  (( $# == 0 )) || usage
else
  (( $# == 1 )) || usage
  ISO_PATTERN="$1"
fi

command -v virsh >/dev/null || die "virsh is not installed"
if ! "$DETACH_ONLY"; then
  command -v virt-xml >/dev/null || die "virt-xml is not installed"

  # `compgen -G` expands the caller's glob without applying shell word
  # splitting, so spaces in ISO paths remain intact.
  mapfile -t matches < <(compgen -G "$ISO_PATTERN" || true)
  ((${#matches[@]})) || die "no ISO matching '$ISO_PATTERN' was found"

  ISO_PATH="${matches[0]}"
  newest_mtime="$(stat -c '%Y' -- "$ISO_PATH")"
  for candidate in "${matches[@]:1}"; do
    candidate_mtime="$(stat -c '%Y' -- "$candidate")"
    if (( candidate_mtime > newest_mtime )); then
      ISO_PATH="$candidate"
      newest_mtime="$candidate_mtime"
    fi
  done

  ABS_ISO_PATH="$(realpath -- "$ISO_PATH")"
  [[ -f "$ABS_ISO_PATH" && -r "$ABS_ISO_PATH" ]] ||
    die "ISO is not a readable regular file: $ABS_ISO_PATH"
  [[ -s "$ABS_ISO_PATH" ]] || die "ISO is empty: $ABS_ISO_PATH"
  [[ "$ABS_ISO_PATH" == *.iso ]] ||
    die "selected file does not have an .iso extension: $ABS_ISO_PATH"

  printf 'Selected ISO: %s\n' "$ABS_ISO_PATH"
fi

# Authenticate once instead of prompting independently for every libvirt edit.
sudo -v
VIRSH=(sudo virsh --connect "$LIBVIRT_URI")
VIRT_XML=(sudo virt-xml --connect "$LIBVIRT_URI")

"${VIRSH[@]}" dominfo "$VM_NAME" >/dev/null 2>&1 ||
  die "libvirt domain '$VM_NAME' does not exist at $LIBVIRT_URI"

VM_STATE="$("${VIRSH[@]}" domstate "$VM_NAME" | tr -d '\r' | xargs)"

if "$DETACH_ONLY"; then
  mapfile -t cdroms < <(
    "${VIRSH[@]}" domblklist "$VM_NAME" --details |
      awk '$2 == "cdrom" { print $3 }'
  )
  if ((${#cdroms[@]} == 0)); then
    printf 'Domain %s has no virtual CD-ROM devices.\n' "$VM_NAME"
    exit 0
  fi

  for target in "${cdroms[@]}"; do
    [[ -n "$target" ]] || continue
    printf 'Ejecting media from CD-ROM target %s...\n' "$target"
    if [[ "$VM_STATE" == "shut off" ]]; then
      "${VIRSH[@]}" change-media "$VM_NAME" "$target" --eject --config
    else
      "${VIRSH[@]}" change-media "$VM_NAME" "$target" \
        --eject --live --config
    fi
  done

  printf 'Ejected all CD-ROM media from domain %s.\n' "$VM_NAME"
  exit 0
fi

if [[ "$VM_STATE" != "shut off" ]]; then
  printf 'Domain %s is %s; forcing it off before changing storage.\n' \
    "$VM_NAME" "$VM_STATE"
  "${VIRSH[@]}" destroy "$VM_NAME"
fi

# A managed-save image can restore the old device graph even after persistent
# XML changes. `--force-boot` bypasses it, but removing it makes that explicit.
if "${VIRSH[@]}" managedsave-remove "$VM_NAME" >/dev/null 2>&1; then
  echo "Removed stale managed-save state."
fi

echo "Removing existing virtual CD-ROM devices..."
mapfile -t old_cdroms < <(
  "${VIRSH[@]}" domblklist "$VM_NAME" --details |
    awk '$2 == "cdrom" { print $3 }'
)
for target in "${old_cdroms[@]}"; do
  [[ -n "$target" ]] || continue
  printf 'Detaching CD-ROM target %s...\n' "$target"
  "${VIRSH[@]}" detach-disk "$VM_NAME" "$target" --config
done

if "${VIRSH[@]}" domblklist "$VM_NAME" --details |
  awk -v target="$CDROM_TARGET" '$3 == target { found = 1 } END { exit !found }'
then
  die "target '$CDROM_TARGET' is already occupied by a non-CD-ROM device"
fi

printf 'Attaching ISO as read-only %s CD-ROM %s...\n' \
  "$CDROM_BUS" "$CDROM_TARGET"
"${VIRSH[@]}" attach-disk \
  "$VM_NAME" "$ABS_ISO_PATH" "$CDROM_TARGET" \
  --config \
  --sourcetype file \
  --type cdrom \
  --targetbus "$CDROM_BUS" \
  --driver qemu \
  --subdriver raw \
  --mode readonly

# Libvirt forbids mixing per-device <boot order='…'/> with the global
# <os><boot dev='…'/></os> list. Clear device orders first, then install one
# deterministic firmware policy: optical media first, installed disk second.
echo "Clearing stale per-device boot ordering..."
PRE_BOOT_XML="$("${VIRSH[@]}" dumpxml "$VM_NAME")"
if grep -q "<boot order=" <<<"$PRE_BOOT_XML"; then
  "${VIRT_XML[@]}" "$VM_NAME" --edit \
    --xml xpath.delete=./devices/disk/boot >/dev/null
else
  echo "No per-device boot ordering was present."
fi

echo "Setting firmware boot order to CD-ROM, then disk..."
"${VIRT_XML[@]}" "$VM_NAME" --edit --boot cdrom,hd,menu=on >/dev/null

DOMAIN_XML="$("${VIRSH[@]}" dumpxml "$VM_NAME")"
if grep -q "<boot order=" <<<"$DOMAIN_XML"; then
  die "per-device boot ordering remains in the domain XML"
fi
if ! grep -q "<boot dev='cdrom'" <<<"$DOMAIN_XML"; then
  die "domain XML does not contain a CD-ROM-first boot policy"
fi
if ! "${VIRSH[@]}" domblklist "$VM_NAME" --details |
  awk -v target="$CDROM_TARGET" \
    '$2 == "cdrom" && $3 == target { found = 1 } END { exit !found }'
then
  die "ISO attachment did not produce CD-ROM target '$CDROM_TARGET'"
fi

echo "Starting VM with the fresh ISO..."
"${VIRSH[@]}" start "$VM_NAME" --force-boot

FINAL_STATE="$("${VIRSH[@]}" domstate "$VM_NAME" | tr -d '\r' | xargs)"
[[ "$FINAL_STATE" == "running" ]] ||
  die "domain failed to enter the running state (state: $FINAL_STATE)"

printf 'Domain %s started with %s attached at %s (%s).\n' \
  "$VM_NAME" "$ABS_ISO_PATH" "$CDROM_TARGET" "$CDROM_BUS"
